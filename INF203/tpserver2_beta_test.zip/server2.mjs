/*"use strict";

import express from "express";
import morgan from "morgan";
import db from "./db.json" assert { type: "json" };


const app = express();
const PORT = process.argv[2] || 8000;

app.use(morgan("dev")); 

app.get("/", (req, res) => {
  res.send("Hi!");
});

app.get("/end", (req, res) => {
  res.send("Server will stop now.");
  process.exit(0);
});

app.get("/restart", (req, res) => {
  db = JSON.parse(fs.readFileSync("db.json", "utf-8"));
  res.send("db.json reloaded");
});

app.get("/countpapers", (req, res) => {
  res.type("text/plain");
  res.send(`${db.length}`);
});

app.get("/byauthor/:author", (req, res) => {
  const author = req.params.author.toLowerCase();
  const count = db.filter((pub) =>
    pub.authors.some((a) => a.toLowerCase().includes(author))
  ).length;
  res.type("text/plain");
  res.send(`${count}`);
});

app.get("/descriptors/:author", (req, res) => {
  const author = req.params.author.toLowerCase();
  const descriptors = db
    .filter((pub) =>
      pub.authors.some((a) => a.toLowerCase().includes(author))
    )
    .map((pub) => pub);
  res.json(descriptors);
});

app.get("/titlelist/:author", (req, res) => {
  const author = req.params.author.toLowerCase();
  const titles = db
    .filter((pub) =>
      pub.authors.some((a) => a.toLowerCase().includes(author))
    )
    .map((pub) => pub.title);
  res.json(titles);
});

app.get("/ref/:key", (req, res) => {
  const key = req.params.key;
  const pub = db.find((item) => item.key === key);
  if (pub) {
    res.json(pub);
  } else {
    res.status(404).json({ error: "Publication not found" });
  }
});

app.delete("/ref/:key", (req, res) => {
  const key = req.params.key;
  const index = db.findIndex((item) => item.key === key);
  if (index !== -1) {
    db.splice(index, 1);
    res.json({ message: `Publication with key ${key} deleted` });
  } else {
    res.status(404).json({ error: "Publication not found" });
  }
});

app.post("/ref", express.json(), (req, res) => {
  const newPub = req.body;
  newPub.key = "imaginary"; 
  db.push(newPub);
  res.json({ message: "Publication added", key: newPub.key });
});

app.put("/ref/:key", express.json(), (req, res) => {
  const key = req.params.key;
  const index = db.findIndex((item) => item.key === key);
  if (index !== -1) {
    
    db[index] = { ...db[index], ...req.body };
    res.json({ message: `Publication with key ${key} updated` });
  } else {
    res.status(404).json({ error: "Publication not found" });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});*/

"use strict";

import express from "express";
import morgan from "morgan";
import db from "./db.json";

const app = express();
const PORT = process.argv[2];

// Logging middleware
app.use(morgan('dev'));

// Middleware to parse JSON requests
app.use(express.json());

// Route to say Hi
app.get('/', (req, res) => {
    res.send('Hi');
});

// Route to stop and exit server
app.get('/end', (req, res) => {
    res.send('Server stopping...');
    process.exit(0);
});

// Route to reload db.json in memory
app.get('/restart', (req, res) => {
    res.send('db.json reloaded');
});

// Route to count papers
app.get('/countpapers', (req, res) => {
    try {
        res.type('text').send(String(db.length));
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to get number of publications by author
app.get('/byauthor/:authorName', (req, res) => {
    const authorName = req.params.authorName.toLowerCase();
    try {
        const count = db.filter(publication => {
            return publication.authors.some(author => author.toLowerCase().includes(authorName));
        }).length;
        res.type('text').send(String(count));
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to get descriptors of publications by author
app.get('/descriptors/:authorName', (req, res) => {
    const authorName = req.params.authorName.toLowerCase();
    try {
        const publications = db.filter(publication => {
            return publication.authors.some(author => author.toLowerCase().includes(authorName));
        });
        res.json(publications);
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to get titles of publications by author
app.get('/titlelist/:authorName', (req, res) => {
    const authorName = req.params.authorName.toLowerCase();
    try {
        const titles = db.filter(publication => {
            return publication.authors.some(author => author.toLowerCase().includes(authorName));
        }).map(publication => publication.title);
        res.json(titles);
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to get publication descriptor by key
app.get('/ref/:key', (req, res) => {
    const key = req.params.key;
    try {
        const publication = db.find(item => item.key === key);
        if (publication) {
            res.json(publication);
        } else {
            res.status(404).send('Publication not found');
        }
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to delete publication by key
app.delete('/ref/:key', (req, res) => {
    const key = req.params.key;
    try {
        const index = db.findIndex(item => item.key === key);
        if (index !== -1) {
            db.splice(index, 1);
            res.send(`Publication with key ${key} deleted`);
        } else {
            res.status(404).send('Publication not found');
        }
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to add new publication
app.post('/ref', (req, res) => {
    try {
        const newPublication = req.body;
        newPublication.key = 'imaginary';
        db.push(newPublication);
        res.send('Publication added');
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Route to update publication by key
app.put('/ref/:key', (req, res) => {
    const key = req.params.key;
    try {
        const index = db.findIndex(item => item.key === key);
        if (index !== -1) {
            db[index] = { ...db[index], ...req.body };
            res.send(`Publication with key ${key} updated`);
        } else {
            res.status(404).send('Publication not found');
        }
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});

